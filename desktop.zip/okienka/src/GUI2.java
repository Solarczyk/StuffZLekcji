import javax.swing.*;

public class GUI2 {
    private static JFrame box;

    GUI2(){
        box = new JFrame();
        JButton btn1 = new JButton("Przycisk 1");
        btn1.setBounds(10, 20, 200, 50);
        box.add(btn1);
        box.setSize(500, 200);
        box.setLayout(null);
        box.setVisible(true);
    }
    public static void main(String[] args) {
        new GUI2();
    }
}
