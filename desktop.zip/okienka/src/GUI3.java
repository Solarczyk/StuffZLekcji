import javax.swing.*;

public class GUI3 extends JFrame {
    GUI3(){
        JButton btn1 = new JButton("Przycisk 1");
        btn1.setBounds(10, 20, 200, 50);
        add(btn1);
        setSize(500, 200);
        this.setLayout(null);
        this.setVisible(true);
    }

    public static void main(String[] args) {
        new GUI3();
    }
}
