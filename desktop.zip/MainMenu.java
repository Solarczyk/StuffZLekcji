/* Classname			- Card
 * Version information	- 1.0.0
 * Date					- 2021-01-03
 * Copyright notice		- Petri Grzegorz
 */
import java.awt.*;
import javax.swing.*;
public class MainMenu extends JFrame{
	// deklaracja globalnych kontenerów
	static JLabel l;
	static JTextArea t;
	static JFrame f;
	static JButton b;
	static JButton b1;
	static JButton b2;
	static JButton b3;
	static JButton b4;
	static JButton b5;
	static JButton bi;
	static JList a;

	public MainMenu(){
		f = new JFrame("textfield");

		l = new JLabel("plik");
		l.setPreferredSize(new Dimension(550, 15));
		l.setVerticalAlignment(JLabel.TOP);
		l.setForeground(new Color(82, 235, 52));
		
		b = new JButton("icon1");
		b1 = new JButton("icon2");
		b2 = new JButton("Otwórz");
		b3 = new JButton("Zapisz");
		bi = new JButton("aa");
		bi.setVisible(false);
		bi.setPreferredSize(new Dimension(5,5));
		b4 = new JButton("Kopiuj");
		b5 = new JButton("Wklej");
		
		String apis[]= { "plik1.txt","plik2.txt","pusty-plik.txt"};
		a = new JList(apis);

		t = new JTextArea();
		JPanel p = new JPanel();
		//setLayout (new BoxLayout (this, BoxLayout.Y_AXIS));  
		p.add(l);
		p.add(b);
		p.add(b1);
		p.add(b2);
		p.add(b3);
		p.add(bi);
		p.add(b4);
		p.add(b5);
		p.add(a);
		p.add(t);
		f.add(p);
		f.setSize(550,350);
		f.setResizable(false);
		f.show();
	}

	public static void main( String[] args){
		new MainMenu();
	}
}