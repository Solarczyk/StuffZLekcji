import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Window2 implements ActionListener{
    int counter = 0;
    String lblTxt = "Liczba kliknięć: ";
    JFrame box = new JFrame();
    JLabel lblCnt = new JLabel(lblTxt+counter);
    JButton btn1, btn2;

    Window2(){
        btn1 = new JButton("c++");
        btn1.setBounds(10,20,200,50);
        btn1.addActionListener(this);
        btn2 = new JButton("Reset");
        btn2.addActionListener(this);
        JPanel pnl = new JPanel();
        pnl.setBorder(BorderFactory.createEmptyBorder(30,30,10,30));

        pnl.setLayout(new GridLayout(0,1));
        pnl.add(btn1);
        pnl.add(lblCnt);

        box.add(pnl, BorderLayout.LINE_END);
        box.add(btn2, BorderLayout.SOUTH);
        box.setTitle("Counter-Button");
        box.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        box.setSize(500,200);
        box.setLocation(500, 0);
        box.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();
        if(src == btn1){
            counter++;
        }
        if(src == btn2){
            counter = 0;
        }
        lblCnt.setText(lblTxt+counter);

    }
    public static void main(String[] args) {
        new Window2();
    }
}
