import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ToolBar extends JToolBar {
    JButton btnMB, btnM1, btn1, btn2, btn3, btn4, btn5;
    ToolBar(JMenuBar mb){
        JToolBar tlb = this;
        btnMB = new JButton("\u2630");
        btnMB.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                mb.setVisible(!mb.isVisible());
            }
        });
        btnM1 = new JButton("\u2756");
        btnM1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                tlb.setFloatable(!tlb.isFloatable());
            }
        });
        btn1 = new JButton("Otwórz");
        btn2 = new JButton("Zapisz");
        btn3 = new JButton("Kopiuj");
        btn4 = new JButton("Wklej");
        btn5 = new JButton();
        btn5.setIcon(new ImageIcon("Icon-Search.png"));

        this.setFloatable(false);
        this.setRollover(true);
        this.add(btnMB);
        this.add(btnM1);
        this.add(btn1);
        this.add(btn2);
        this.addSeparator();

    }
}
