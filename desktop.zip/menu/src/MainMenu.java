import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainMenu extends JMenuBar implements ActionListener {
    JMenuBar bar;
    JPanel pnl, pnl2;
    JMenu menu, submenu;
    JFrame box = new JFrame();
    JMenuItem it1, it2, it3, sub1, sub2;

    MainMenu(){

        bar = new JMenuBar();
        menu = new JMenu("Plik");

        it1 = new JMenuItem("Otwórz");
        it1.addActionListener(this);
        menu.add(it1);
        it2 = new JMenuItem("Zapisz");
        it2.addActionListener(this);
        menu.add(it2);
        submenu = new JMenu("Submenu");
        sub1 = new JMenuItem("opcja4");
        sub1.addActionListener(this);
        submenu.add(sub1);
        sub2 = new JMenuItem("opcja5");
        sub2.addActionListener(this);
        submenu.add(sub2);
        menu.add(submenu);
        it3 = new JMenuItem("Wyjdź");
        it3.addActionListener(this);
        menu.add(it3);
        bar.add(menu);


        pnl = new JPanel();
        pnl2 = new JPanel();
        pnl2.setSize(100, 100);
        pnl.setBorder(BorderFactory.createEmptyBorder(50,30,10,30));

        pnl.setLayout(new BorderLayout(0,1));
        pnl2.add(bar, BorderLayout.PAGE_START);
        pnl2.add(new ToolBar(bar), BorderLayout.AFTER_LINE_ENDS);
        box.add(pnl2, BorderLayout.CENTER);
        box.add(pnl, BorderLayout.CENTER);

        box.setTitle("MainMenu");
        box.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        box.setSize(500,200);
        box.setLocation(500, 0);
        box.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();

        if(src==it1){
            pnl.setBackground(Color.RED);
        }
        if(src==it2){
            pnl.setBackground(Color.GREEN);
        }
        if(src==sub1){
            pnl.setBackground(Color.BLUE);
        }
        if(src==sub2){
            pnl.setBackground(Color.YELLOW);
        }
        if(src==it3){
            box.dispose();
        }
    }
}
